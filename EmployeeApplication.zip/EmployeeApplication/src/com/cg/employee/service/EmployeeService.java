package com.cg.employee.service;

import java.util.ArrayList;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;



public interface EmployeeService {
	/*String pattern="[A-Z]{1}[a-z]{2,}";*/
	int addEmployee(Employee emp)throws EmployeeException;

	Employee removeEmployee(int empId)throws EmployeeException;

	Employee getEmployeeById(int empId)throws EmployeeException;

	ArrayList<Employee> getAllEmployee()throws EmployeeException;

	Employee updateEmployee(int empId,int empsal) throws EmployeeException;
	
	
	//public boolean validateempDate(String date);
	boolean validateempName(String name) ;

	boolean validateempSalary(int salary);
	
	
		
		
	
}
