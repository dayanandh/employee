package com.cg.employee.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao;

	public EmployeeDao getDao() {
		return dao;
	}

	public void setDao(EmployeeDao dao) {
		this.dao = dao;
	}

	public EmployeeServiceImpl() {

		dao=new EmployeeDaoImpl();
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {

		return dao.addEmployee(emp);
	}

	@Override
	public Employee removeEmployee(int empId) throws EmployeeException {

		return dao.removeEmployee(empId);
	}

	@Override
	public Employee getEmployeeById(int empId) throws EmployeeException {

		return dao.getEmployeeById(empId);
	}

	@Override
	public ArrayList<Employee> getAllEmployee() throws EmployeeException {

		return dao.getAllEmployee();
	}

	@Override
	public Employee updateEmployee(int empId, int empsal)
			throws EmployeeException {

		return dao.updateEmployee(empId, empsal);
	}

	/*@Override
	public boolean validateEmployee(Employee emp)  {
		if(validateempName(emp.getEmpName())){
			if(validateempSalary(emp.getEmpSal())){
				return true;
			}else
				return false;
		}
		return false;
	}*/

	@Override
	public boolean validateempName(String name)  {
		String pattern="[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern, name)){
			return true;
		}else
			return false;

	}
	@Override
	public boolean validateempSalary(int salary)  {
		String pattern="[0-9]{4,6}";
		String sal=""+salary;
		if(Pattern.matches(pattern, sal)){
			return true;
		}else
			return false;

	}
	/*@Override
	public boolean validateempDate(String date)  {
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bdate=LocalDate.parse(date,formatter);
		if(bdate!=null){
			return true;
		}else
			return false;
	}*/
	
}
