package com.cg.employee.logger4j;

import java.io.IOException;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class MyLogger {
	static Logger logger;// root logger class
	static
	{
		logger=Logger.getLogger(MyLogger.class);//instance of my logger
		SimpleLayout layout=new SimpleLayout();// config the layout

		try {
			FileAppender appender=new FileAppender(layout,"basic.log");
			logger.addAppender(appender);
			logger.setLevel(Level.DEBUG);
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
	public static Logger getLogger(){
		return logger;

	}
}
